from django.shortcuts import render
from django.http import HttpResponseRedirect, HttpResponseBadRequest, HttpResponse
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from .models import Aluno
from django.contrib.auth import logout

def home_page(request):
    return render(request, 'home.html')

def login_view(request):
    if request.method == 'GET':
       return render(request, 'login.html' ,{
           'incorrect_login': False
       })
    elif request.method =='POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return HttpResponseRedirect('/home')
        else:
         return render(request, 'login.html', {
               'incorrect_login': True
        })
    else:
        return HttpResponseBadRequest()
    

@login_required(login_url='/login')
def forms_view(request):
    if request.method == 'GET':
        return render(request, 'forms.html' ,{
            'username': request.user.username
        })
    elif request.method =='POST':
        nome = request.POST['nome']
        nome_responsavel = request.POST['nome_responsavel']
        email = request.POST['email']
        curso = request.POST['curso'] 
        periodo = request.POST['periodo']
        telefone = request.POST['telefone']
        endereço = request.POST['endereco']
        aluno = Aluno()
        aluno.nome = nome
        aluno.nome_responsavel = nome_responsavel
        aluno.email = email
        aluno.curso = curso
        aluno.periodo = periodo
        aluno.telefone = telefone
        aluno.endereco = endereço
        aluno.save()
        return HttpResponseRedirect('/home')
    else:
        return HttpResponseBadRequest()

def logout_view(request):
   logout(request)
   return HttpResponseRedirect('http://127.0.0.1:8000/')


def exibir_page(request):
    alunos = Aluno.objects.all()
    return render(request, 'exibir.html',{
        'alunos' : alunos
    })


def sobre_page(request):
    return render(request, 'sobre.html')

