from django.db import models

class Aluno(models.Model):
    nome = models.CharField(max_length=100)
    nome_responsavel = models.CharField(max_length=100, null=True, default=None)
    email = models.EmailField(null=True, default=None)
    CURSOS_CHOICES = [
        ('Filosofia', 'Filosofia'),
        ('Ingles', 'Ingles'),
        ('Portugues', 'Portugues'),
        ('Matematica', 'Matematica'),
        ('Fisica', 'Fisica'),
        ('Sociologia', 'Sociologia'),
        ('Geografia', 'Geografia'),
        ('Quimica', 'Quimica'),
        ('Historia', 'Historia'),
    ]
    curso = models.CharField(max_length=50, choices=CURSOS_CHOICES, null=True, default=None)
    PERIODO_CHOICES = [
        ('Matutino', 'Matutino'),
        ('Vespertino', 'Vespertino'),
        ('Noturno', 'Noturno'),
    ]
    periodo = models.CharField(max_length=50, choices=PERIODO_CHOICES, null=True, default=None)
    telefone = models.CharField(max_length=20, blank=True, null=True, default=None)
    endereco = models.TextField(blank=True, null=True, default = None)

    def __str__(self):
        return self.nome

